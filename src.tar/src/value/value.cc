/*
 * value.cc
 *
 *  Created on: 2015. 5. 19.
 *      Author: windfree
 */
#include "value/value.h"
namespace spotter {

value::value() {};
value::~value() {};

}



