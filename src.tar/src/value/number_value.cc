/*
 * number_value.cc
 *
 *  Created on: 2015. 5. 11.
 *      Author: windfree
 */

#include "value/number_value.h"

namespace spotter {

number_value::number_value() {
	// TODO Auto-generated constructor stub

}

number_value::~number_value() {
	// TODO Auto-generated destructor stub
}

} /* namespace spotter */
