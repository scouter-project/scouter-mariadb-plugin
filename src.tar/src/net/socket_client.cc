/*
 * data_sender.cc
 *
 *  Created on: 2015. 4. 28.
 *      Author: windfree
 */

#include <net/socket_client.h>

namespace spotter {
socket_client::socket_client(struct sockaddr* serv_addr) {
	// TODO Auto-generated constructor stub

}
socket_client::socket_client() {

}

socket_client::~socket_client() {
	// TODO Auto-generated destructor stub
}

} /* namespace spotter */
