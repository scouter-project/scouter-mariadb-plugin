/*
 * net_constants.cc
 *
 *  Created on: 2015. 9. 21.
 *      Author: windfree
 */

#include "net/net_constants.h"

namespace spotter {

char net_constants::SINGLE_PACK[]={'J','A','V','A'};
char net_constants::MULTI_PACK[]={'J','A','V','N'};
//char net_constants::MTU_PACK[]={'J','M','T','U'};
char net_constants::MTU_PACK[]={'C','A','F','M'};

} /* namespace spotter */
