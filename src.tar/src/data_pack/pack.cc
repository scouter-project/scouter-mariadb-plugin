/*
 * pack.cc
 *
 *  Created on: 2015. 4. 23.
 *      Author: windfree
 */

#include "data_pack/pack.h"
#include "io/data_output.h"
namespace spotter {

pack::pack() {
	// TODO Auto-generated constructor stub

}

pack::~pack() {
	// TODO Auto-generated destructor stub
}

} /* namespace spotter */
