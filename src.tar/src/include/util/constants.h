/*
 * constants.h
 *
 *  Created on: 2015. 7. 27.
 *      Author: windfree
 */

#ifndef SRC_UTIL_CONSTANTS_H_
#define SRC_UTIL_CONSTANTS_H_
static const int PFS_EVT_STMT_CURRENT_COL_CNT = 14;
static const int PFS_EVT_STMT_SUMMARY_COL_CNT = 29;
static const int TCP_AGENT = 0xCAFE1001;




#endif /* SRC_UTIL_CONSTANTS_H_ */
